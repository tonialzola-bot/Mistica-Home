import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Trash, CheckCircle, CreditCard, Receipt } from 'lucide-react';

const ShoppingCart = ({ cartItems, isOpen, onClose, onRemoveItem, onClearCart }) => {
  const [couponCode, setCouponCode] = useState('');
  const [couponApplied, setCouponApplied] = useState(false);
  const [couponError, setCouponError] = useState('');
  const [purchaseConfirmed, setPurchaseConfirmed] = useState(false);
  const [showReceipt, setShowReceipt] = useState(false);

  const subtotal = cartItems.reduce((sum, item) => sum + item.price, 0);
  const discount = couponApplied ? subtotal * 0.15 : 0;
  const total = subtotal - discount;

  const handleApplyCoupon = () => {
    const code = couponCode.toUpperCase();
    if (code === 'WELCOME10' || code === 'SUMMER15') {
      setCouponApplied(true);
      setCouponError('');
    } else {
      setCouponApplied(false);
      setCouponError('Cupón no válido. Prueba WELCOME10 (15% off) o SUMMER15 si tienes +3 items.');
    }
  };

  const handleRemoveCoupon = () => {
    setCouponApplied(false);
    setCouponCode('');
    setCouponError('');
  };

  const handlePurchase = () => {
    if (cartItems.length === 0) return;
    onClearCart();
    setPurchaseConfirmed(true);
    setTimeout(() => {
      setPurchaseConfirmed(false);
      setShowReceipt(true); // Mostrar recibo después de la confirmación
    }, 2000);
  };

  // Recibo simulado (placeholder para integración real con Stripe)
  const ReceiptModal = () => (
    <AnimatePresence>
      {showReceipt && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
          onClick={() => {
            setShowReceipt(false);
            onClose();
          }}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-white rounded-2xl p-8 max-w-md w-full max-h-[80vh] overflow-y-auto shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-6">
              <Receipt className="w-8 h-8 text-emerald-500" />
              <h2 className="text-2xl font-bold text-gray-800 font-[Poppins]">Recibo de Compra</h2>
              <motion.button
                onClick={() => setShowReceipt(false)}
                className="text-gray-500 hover:text-gray-700"
                whileHover={{ scale: 1.1 }}
              >
                <X className="w-6 h-6" />
              </motion.button>
            </div>
            <div className="space-y-4 mb-6">
              <p className="text-sm text-gray-600 font-[Lato]"><strong>ID de Pedido:</strong> #ORD-{Math.random().toString(36).substr(2, 9).toUpperCase()}</p>
              <p className="text-sm text-gray-600 font-[Lato]"><strong>Fecha:</strong> {new Date().toLocaleDateString()}</p>
              <p className="text-sm text-gray-600 font-[Lato]"><strong>Total Pagado:</strong> ${total.toFixed(2)}</p>
              <p className="text-sm text-gray-600 font-[Lato]"><strong>Método:</strong> Tarjeta de Crédito (Simulado - Integra Stripe aquí)</p>
            </div>
            <div className="border-t pt-4">
              <p className="text-xs text-gray-500 font-[Lato] text-center">
                *En producción: Usa Stripe Elements para formulario de pago real.<br />
                <a href="https://stripe.com/docs/payments/accept-a-payment" target="_blank" className="text-emerald-600 underline">Guía de Stripe</a>
              </p>
            </div>
            <motion.button
              onClick={() => setShowReceipt(false)}
              className="w-full mt-6 py-3 bg-emerald-600 text-white rounded-full font-semibold"
              whileHover={{ scale: 1.05 }}
            >
              Descargar PDF (Próximamente)
            </motion.button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );

  if (purchaseConfirmed) {
    return (
      <motion.div
        initial={{ x: '100%' }}
        animate={{ x: 0 }}
        className="fixed inset-y-0 right-0 w-80 bg-white shadow-lg p-6 flex flex-col items-center justify-center z-50 rounded-l-2xl border-l border-gray-100"
      >
        <CheckCircle className="w-20 h-20 text-emerald-500 mb-4 animate-bounce" />
        <h2 className="text-2xl font-bold text-emerald-600 font-[Poppins] mb-2">¡Procesando Pago!</h2>
        <p className="text-gray-600 font-[Lato] text-center">Tu transacción está siendo verificada de forma segura. ¡Momento!</p>
        <div className="mt-4 w-full bg-gray-200 rounded-full h-2">
          <motion.div
            className="bg-emerald-500 h-2 rounded-full"
            initial={{ width: 0 }}
            animate={{ width: '100%' }}
            transition={{ duration: 2 }}
          />
        </div>
      </motion.div>
    );
  }

  return (
    <div>
      <AnimatePresence>
        {isOpen && !purchaseConfirmed && (
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed inset-y-0 right-0 w-80 bg-white shadow-lg p-6 overflow-y-auto z-50 rounded-l-2xl border-l border-gray-100"
          >
            <div className="flex justify-between items-center mb-6 border-b pb-4 border-gray-100">
              <h2 className="text-2xl font-bold text-gray-800 font-[Poppins]">Tu Carrito</h2>
              <div className="flex gap-2">
                {cartItems.length > 0 && (
                  <motion.button
                    onClick={onClearCart}
                    className="text-gray-500 hover:text-red-700 p-2 rounded-full hover:bg-red-100 transition-colors"
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                  >
                    <Trash className="w-5 h-5" />
                  </motion.button>
                )}
                <motion.button
                  onClick={onClose}
                  className="text-gray-500 hover:text-gray-700 p-2 rounded-full hover:bg-gray-100 transition-colors"
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                >
                  <X className="w-6 h-6" />
                </motion.button>
              </div>
            </div>

            {cartItems.length === 0 ? (
              <p className="text-gray-500 font-[Lato]">Tu carrito está vacío, ¡es hora de llenarlo!</p>
            ) : (
              <div className="space-y-4">
                {cartItems.map((item) => (
                  <motion.div
                    key={item.cartItemId || item.id}
                    layout
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="flex items-center gap-4 border-b border-gray-100 pb-4 last:border-b-0"
                  >
                    <img src={item.imageUrl} alt={item.name} className="w-20 h-20 object-cover rounded-md shadow-sm" />
                    <div className="flex-grow">
                      <h3 className="font-semibold text-gray-800 font-[Poppins]">{item.name}</h3>
                      <p className="text-sm text-gray-500 font-[Lato]">{item.category}</p>
                      {item.discount && <span className="text-xs bg-red-100 text-red-600 px-2 py-1 rounded-full font-[Poppins]">{item.discount}</span>}
                    </div>
                    <span className="font-bold text-emerald-600 font-[Poppins]">${item.price.toFixed(2)}</span>
                    <motion.button
                      onClick={() => onRemoveItem(item.cartItemId || item.id)}
                      className="text-gray-400 hover:text-red-500 p-1 rounded-full hover:bg-red-50"
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                    >
                      <X className="w-4 h-4" />
                    </motion.button>
                  </motion.div>
                ))}

                <div className="border-t border-gray-200 pt-4">
                  <div className="flex gap-2 mb-2">
                    <input
                      type="text"
                      value={couponCode}
                      onChange={(e) => setCouponCode(e.target.value)}
                      placeholder="Código de descuento"
                      className="flex-grow px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500 font-[Lato]"
                    />
                    {!couponApplied ? (
                      <motion.button
                        onClick={handleApplyCoupon}
                        className="px-4 py-2 bg-gradient-to-r from-red-500 to-pink-500 text-white rounded-md font-semibold hover:from-red-600"
                        whileHover={{ scale: 1.05 }}
                      >
                        ¡Aplica!
                      </motion.button>
                    ) : (
                      <motion.button
                        onClick={handleRemoveCoupon}
                        className="px-4 py-2 bg-gray-500 text-white rounded-md font-semibold hover:bg-gray-600"
                        whileHover={{ scale: 1.05 }}
                      >
                        Quitar
                      </motion.button>
                    )}
                  </div>
                  {couponError && <p className="text-sm text-red-500 font-[Lato]">{couponError}</p>}
                  {couponApplied && <p className="text-sm text-green-600 font-[Lato]">¡Cupón aplicado! 15% off. ✨</p>}
                </div>

                <div className="border-t border-gray-200 pt-4 mt-6 space-y-2">
                  <div className="flex justify-between">
                    <span className="font-semibold font-[Poppins]">Subtotal:</span>
                    <span className="font-[Lato]">${subtotal.toFixed(2)}</span>
                  </div>
                  {discount > 0 && (
                    <div className="flex justify-between text-green-600 font-bold">
                      <span>Descuento:</span>
                      <span>-${discount.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="border-t pt-2 flex justify-between items-center">
                    <span className="text-xl font-bold font-[Poppins]">Total:</span>
                    <span className="text-2xl font-extrabold text-emerald-700 font-[Poppins]">${total.toFixed(2)}</span>
                  </div>
                </div>

                {/* Placeholder para formulario de pago real (Stripe Elements) */}
                <div className="border border-gray-200 rounded-lg p-4 bg-gray-50 mt-4">
                  <h3 className="font-semibold font-[Poppins] mb-2 flex items-center gap-2">
                    <CreditCard className="w-4 h-4" /> Pago Seguro (Simulado)
                  </h3>
                  <p className="text-xs text-gray-500 font-[Lato]">
                    En producción, integra Stripe Elements aquí para aceptar tarjetas reales. Es fácil: crea una cuenta en stripe.com, obtén tu clave pública y envuelve tu app con Elements. No hay promesas rotas – ¡solo configuraciones seguras!
                    <br /><br />
                    <a href="https://stripe.com/docs/payments/accept-a-payment" target="_blank" className="text-emerald-600 underline block mt-2">Guía oficial de Stripe (hazlo tú)</a>
                  </p>
                </div>

                <motion.button
                  onClick={handlePurchase}
                  disabled={cartItems.length === 0}
                  className={`w-full py-3 rounded-full font-semibold text-lg flex items-center justify-center gap-2 ${cartItems.length === 0 ? 'bg-gray-400 text-white cursor-not-allowed' : 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white hover:shadow-xl'}`}
                  whileHover={cartItems.length > 0 ? { scale: 1.05 } : {}}
                  whileTap={cartItems.length > 0 ? { scale: 0.95 } : {}}
                >
                  <CreditCard className="w-5 h-5" />
                  Pagar con Tarjeta Segura
                </motion.button>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
      <ReceiptModal />
    </div>
  );
};

export default ShoppingCart;