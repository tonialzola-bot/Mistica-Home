import React from 'react';
import { motion } from 'framer-motion';
import { ShoppingCart } from 'lucide-react';

const ProductCard = ({ product, handleAddToCart }) => {
  return (
    <motion.div
      className="relative bg-white/70 backdrop-blur-sm rounded-2xl p-6 shadow-md hover:shadow-xl transition-all duration-300 border border-gray-100 flex flex-col items-center text-center"
      whileHover={{ translateY: -8, scale: 1.02 }}
      initial={{ opacity: 0, scale: 1 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.8 }}
      transition={{ duration: 0.3 }}
    >
      {product.discount && (
        <motion.span 
          className="absolute top-4 left-4 bg-gradient-to-r from-red-500 to-pink-500 text-white text-xs font-bold px-3 py-1 rounded-full shadow-md z-10 font-[Poppins] flex items-center gap-1"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          whileHover={{ scale: 1.1 }}
        >
          ✨ {product.discount}
        </motion.span>
      )}
      <div className="w-48 h-48 mb-4">
        <motion.img
          src={product.imageUrl}
          alt={product.name}
          className="w-full h-full object-cover rounded-xl shadow-inner border border-gray-200"
          whileHover={{ scale: 1.05 }}
          transition={{ duration: 0.3 }}
        />
      </div>
      <h3 className="text-xl font-bold text-gray-800 mb-2 font-[Poppins]">{product.name}</h3>
      <p className="text-sm text-gray-600 mb-4 flex-grow font-[Lato]">{product.description}</p>
      <div className="flex items-center justify-center gap-3 mb-5">
        {product.originalPrice && (
          <span className="text-lg text-gray-400 line-through font-[Lato]">${product.originalPrice.toFixed(2)}</span>
        )}
        <span className="text-2xl font-bold text-emerald-600 font-[Poppins]">${product.price.toFixed(2)}</span>
      </div>
      <motion.button
        onClick={() => handleAddToCart(product)}
        className="w-full py-3 bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-full font-semibold flex items-center justify-center gap-2 shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <ShoppingCart className="w-5 h-5" />
        Añadir al Carrito
      </motion.button>
    </motion.div>
  );
};

export default ProductCard;