import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import ProductCard from './components/ProductCard'; // Usaremos este como base, lo renombraré si es necesario.
import ShoppingCart from './components/ShoppingCart'; 
import { Leaf, Filter, ShoppingCart as ShoppingCartIcon } from 'lucide-react'; 

// Datos de tus productos, ahora con categorías y descuentos (simulados)
const allProducts = [
  {
    id: '1',
    name: 'Difusor de Aromas Ultrasónico con Luces LED',
    description: 'Transforma tu ambiente con este elegante difusor. Utiliza tecnología ultrasónica para dispersar aceites esenciales, acompañado de suaves luces LED que cambian de color, creando una atmósfera de calma y serenidad.',
    price: 49.99,
    originalPrice: 59.99,
    imageUrl: 'https://images.unsplash.com/photo-1627067868000-0e1d0f5e1f0e?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    category: 'Aromaterapia',
    discount: '17% OFF',
  },
  {
    id: '2',
    name: 'Set de Aceites Esenciales Naturales (4 piezas)',
    description: 'Colección premium de aceites esenciales puros: Lavanda para relajar, Eucalipto para purificar, Menta para energizar y Limón para revitalizar. Perfectos para aromaterapia y bienestar integral.',
    price: 35.50,
    originalPrice: 42.00,
    imageUrl: 'https://images.unsplash.com/photo-1600861194943-559d81373e21?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    category: 'Aromaterapia',
    discount: '15% OFF',
  },
  {
    id: '3',
    name: 'Rodillo Facial de Jade y Gua Sha (Kit)',
    description: 'El dúo perfecto para el autocuidado facial. El rodillo de jade ayuda a reducir la hinchazón y mejora la circulación, mientras que el Gua Sha esculpe y relaja los músculos faciales, promoviendo una piel radiante.',
    price: 29.00,
    originalPrice: 34.00,
    imageUrl: 'https://images.unsplash.com/photo-1596462719601-3e0f9c2d1b0d?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    category: 'Cuidado Facial',
    discount: '15% OFF',
  },
  {
    id: '4',
    name: 'Vela Aromática Artesanal de Soja "Calma Profunda"',
    description: 'Hecha a mano con cera de soja 100% natural y aceites esenciales de sándalo y pachulí. Su suave fragancia crea un ambiente de paz y relajación profunda, ideal para meditar o descansar.',
    price: 19.99,
    originalPrice: 24.99,
    imageUrl: 'https://images.unsplash.com/photo-1627993096316-2c9dd734892c?q=80&w=1935&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    category: 'Aromaterapia',
    discount: '20% OFF',
  },
  {
    id: '5',
    name: 'Mascarilla Facial de Arcilla Natural Detox',
    description: 'Una potente mascarilla de arcilla formulada con ingredientes naturales para limpiar profundamente, desintoxicar y revitalizar la piel. Rica en minerales, deja tu piel suave y radiante.',
    price: 18.25,
    originalPrice: 20.00,
    imageUrl: 'https://images.unsplash.com/photo-1620215904838-b7d609c2a52d?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    category: 'Cuidado Facial',
    discount: '8% OFF',
  },
  {
    id: '6',
    name: 'Humidificador Portátil USB "Nube Personal"',
    description: 'Lleva la humedad y el frescor donde vayas. Este mini humidificador recargable por USB mejora la calidad del aire y puede usarse con unas gotas de aceite esencial para una experiencia de aromaterapia individual.',
    price: 25.00,
    originalPrice: 30.00,
    imageUrl: 'https://images.unsplash.com/photo-1616262444634-118c7c98064d?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    category: 'Hogar y Ambiente',
    discount: '16% OFF',
  },
  {
    id: '7',
    name: 'Pulsera Difusora de Aromaterapia "Equilibrio"',
    description: 'Un accesorio elegante y funcional. Esta pulsera de lava volcánica natural absorbe tus aceites esenciales favoritos, permitiéndote disfrutar de sus beneficios terapéuticos durante todo el día, en cualquier lugar.',
    price: 14.50,
    originalPrice: 17.00,
    imageUrl: 'https://images.unsplash.com/photo-1604176466981-b2b9f67a2118?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    category: 'Accesorios',
    discount: '14% OFF',
  },
];


const App = () => {
  const [selectedCategory, setSelectedCategory] = useState('Todos');
  const [cartItems, setCartItems] = useState([]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  const categories = ['Todos', ...new Set(allProducts.map(p => p.category))];

  const filteredProducts = selectedCategory === 'Todos'
    ? allProducts
    : allProducts.filter(product => product.category === selectedCategory);

  const handleAddToCart = (product) => {
    setCartItems((prevItems) => [...prevItems, {...product, cartItemId: `${product.id}-${Date.now()}`}]); // Añade un ID único para el carrito
    setIsCartOpen(true); 
  };

  const handleRemoveItem = (cartItemIdToRemove) => {
    setCartItems((prevItems) => prevItems.filter((item) => item.cartItemId !== cartItemIdToRemove));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-stone-50 to-emerald-50 text-gray-800 p-8">
      <motion.header
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="text-center mb-10 relative" 
      >
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
          className="mx-auto w-24 h-24 bg-gradient-to-tr from-emerald-200 to-teal-200 rounded-full flex items-center justify-center mb-6 shadow-xl"
        >
          <Leaf className="w-12 h-12 text-emerald-700" strokeWidth={1.5} />
        </motion.div>
        
        <h1 className="text-5xl font-extrabold tracking-tight text-gray-900 leading-tight font-[Poppins]">
          Nuestros <span className="text-emerald-600">Productos</span>
        </h1>
        <p className="mt-6 text-xl text-gray-600 max-w-2xl mx-auto font-[Lato] leading-relaxed">
          Encuentra el bienestar que buscas con nuestra exclusiva selección de productos naturales y artesanales.
        </p>

        {/* Botón del carrito */}
        <motion.button
          onClick={() => setIsCartOpen(true)}
          className="absolute top-0 right-0 p-3 bg-white rounded-full shadow-lg border border-gray-100 text-gray-700 hover:bg-emerald-50 hover:text-emerald-600 transition-all duration-300"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
        >
          <ShoppingCartIcon className="w-6 h-6" />
          {cartItems.length > 0 && (
            <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
              {cartItems.length}
            </span>
          )}
        </motion.button>
      </motion.header>

      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5, duration: 0.5 }}
        className="flex justify-center items-center gap-4 mb-12 flex-wrap"
      >
        <Filter className="w-5 h-5 text-gray-600" />
        {categories.map(category => (
          <motion.button
            key={category}
            onClick={() => setSelectedCategory(category)}
            className={`px-5 py-3 rounded-full font-semibold text-lg transition-all duration-300 shadow-sm ${
              selectedCategory === category
                ? 'bg-emerald-600 text-white shadow-lg'
                : 'bg-white text-gray-700 hover:bg-emerald-50 hover:text-emerald-600 border border-gray-200'
            }`}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            {category}
          </motion.button>
        ))}
      </motion.div>

      <div className="container mx-auto">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 justify-items-center">
          <AnimatePresence mode="wait">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                handleAddToCart={handleAddToCart}
              />
            ))}
          </AnimatePresence>
        </div>
      </div>

      <ShoppingCart 
        cartItems={cartItems} 
        isOpen={isCartOpen} 
        onClose={() => setIsCartOpen(false)} 
        onRemoveItem={handleRemoveItem} // Pasar la función para eliminar un ítem
        onClearCart={handleClearCart}   // Pasar la función para vaciar el carrito
      />
    </div>
  );
};

export default App;